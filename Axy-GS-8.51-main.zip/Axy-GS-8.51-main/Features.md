# Main
Discord: "@jyzo.",
**STAR FOR MORE UPDATES**
</br>
**PLEASE NOTE: THIS SOURCE IS GONNA BE RARELY UPDATED**
</br>

# Features
KURV@!!

### Farming
  - [x] Proper
  - [ ] Multiplyer from playlist data
### Building/Editing
  - [X] F3 EOR support
  - [ ] More client sided shit that makes less lag
### Proper Teams
  - [ ] Squads + Rebooting
### Different ltms support
  - [x] Playground (gaymode)
  - [ ] Onshot
  - [ ] FloorIsLava
  - [ ] Creative
### Respawning
  - [x] Proper
  - [ ] Creative respawns
  - [ ] LG respawns
### Proper hooking
  - [ ] uhm maybe
### Vehicles
  - [ ] Fix sync with srvr
### Lategame
  - [ ] Random loot grand __Not finished yet__
  - [x] Proper Zones for grand finals skidda
  - [x] Proper bus
### Emoting
  - [ ] Fix delay
### Looting (unproper wont be fixed)

### AutoPickup (never)

### Change Teams in Playground etc...
  - [ ] uhm maybe
  - [ ] uhm idfk
### MCP (bugged)
  - [x] skins
  - [x] back packs
  - [x] gliders
  - [ ] pickaxes
  - [ ] emotes (not marked since we need to fix this shit)
### Uptime webhook
  - [x] Server Starting
  - [x] server up
  - [x] match has started 
 
# Credits
*Dumped SDK with*: [Dumper-7](https://github.com/Encryqed/Dumper-7)
