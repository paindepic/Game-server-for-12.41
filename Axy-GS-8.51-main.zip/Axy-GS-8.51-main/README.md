# Axy-GS-8.51
Shitty skid  ALSO the project Never released! </br>
A season 8 gs which is mostly a skid from Volcano 8.51 but wtv...

> **Features** </br>
> Check the `Features.md` 
> 
> **Configure the gs** </br>
> Go to: `Axy-GS-8.51\VolcanoV2\Volcano-8.51\framework.h` </br>
> (`framework.h`) and configure to your own needs
> 
> **What did i made better on this gs?**
> - Almost nothing
> - LateGame with random loot and proper bus start (without crashing)
> - Fixed Playground respawns


# Why this is getting released / leaked?
So basically my friend `@lacigaziga2000_94020` | `id:1360174957446959164` on discord wanted to make a "FMod" type of S8 project and hiered me to Skid / moddify the  **Volcano 8.51 gs** for him.  He is a type of guy who cant code in **C++** so i helped him and he ALSO modded **Burlone's FMod launcher**  for his i said  this to him when He wanted me to add the logo and the design to it `"I dont care if u gonna get called as a Skidder or wtv IF ur server gets nuked i will Not help u grow that shit back up!!"` </br>

Also he kept changing the logo and the design all the fucking time which pissed me off and yesterday (in Nov 28. 2025).  He wanned to rename the project to *`Project Ryxe`* (which he did 🤦‍♂️) obv its a very shitty name and he stole a R logo from google </br>

Here it is btw:

<img width="240" height="87" alt="Képernyőkép 2025-11-29 165318" src="https://github.com/user-attachments/assets/3e2da34f-0943-48ef-a274-41d92dc53e53" />
And i didnt wannted to re-design the Launcher and server for him which pissed me soo off so i told him `" mf  did u at least changed the launcher?"` and Ofc he said No and i was really angry  BTW he did NOTHING on his gs or backend was just reload with No credits pretty much! and after all that i told him:

*"ok then im Never gonna help u if u keep making STUPID things and u calling it 'i was bored'  like tf  bro"* he said *"chill"* like BRU he did basically NOTHING to his own shit  im fucking done  and NEVER hire me to skid for u if u are not doing shit!!!

AND ALSO After all that he said he is gonna delete the server:
<img width="600" height="400" alt="Képernyőkép 2025-11-29 165254" src="https://github.com/user-attachments/assets/3380bcb1-7f84-43d9-9292-ed3a0dc21817" />
ALSO he didnt said shit about what he did even tho he included my server so i said soo many TRUE and VALID things about him.

**SO im fucking done  with this guy  FOREVER!**
