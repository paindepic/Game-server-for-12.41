techs skunky gpt bots code for 10.40 (no i am not leaking the gs since tim made the gs and i respect him)
